
function bang()
{
	var p = this.patcher;
	var w = p.wind;
	post(""+w.visible);
}