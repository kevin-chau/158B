
CNMAT odot download page:
https://github.com/CNMAT/CNMAT-odot/releases/tag/v1.0.9rc9-mmjss2015

Other required packages are available from the Max package manager, or online: 
CNMAT-Externals, cv.jit, xray, and zsa.descriptors

Driver for Wacom Intuos Pro:
(scroll down!)
http://www.wacom.com/en-us/support/product-support/drivers

logitech driver:
http://support.logitech.com/en_us/product/webcam-c930e-business
also get the mac app:
https://itunes.apple.com/us/app/logitech-camera-settings/id638332853?mt=12
