
CNMAT odot download page:
https://github.com/CNMAT/CNMAT-odot/releases/tag/v1.0.9rc9-mmjss2015

Other required packages are available from the Max package manager: 
CNMAT-Externals, cv.jit, xray, and zsa.descriptors, available from 

